/**
 * Maç Ekranı yayın verisi köprüsü — Cloudflare Worker
 * Deploy: Cloudflare Dashboard > Workers & Pages > Create Worker > paste this file.
 * Endpoint: GET /api/broadcasts?date=YYYY-MM-DD
 * Source attribution is returned with every response. Confirm source reuse permission before public/paid launch.
 */
const ORIGIN = 'https://www.yayinekrani.com';
const UA = 'MacEkrani/1.0 (Turkiye futbol yayin rehberi)';
const CHANNELS = [
  'beIN Sports 1','beIN Sports 2','beIN Sports 3','beIN Sports 4','beIN Sports 5','beIN Sports MAX 1','beIN Sports MAX 2',
  'TRT 1','TRT Spor','TRT Spor Yildiz','A Spor','S Sport','S Sport 2','tabii Spor','tabii Spor 1','tabii Spor 2',
  'Exxen','CBC Sport','Tivibu Spor','HT Spor','TV8,5','TV8'
];
const norm = s => (s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase('tr').replace(/ı/g,'i').replace(/[^a-z0-9]+/g,' ').trim();
const textOnly = html => decode(html.replace(/<script[\s\S]*?<\/script>/gi,' ').replace(/<style[\s\S]*?<\/style>/gi,' ').replace(/<[^>]+>/g,' ').replace(/&nbsp;|&#160;/gi,' ').replace(/&amp;/gi,'&').replace(/&#39;|&apos;/gi,"'").replace(/&quot;/gi,'"').replace(/&uuml;/gi,'ü').replace(/&Uuml;/g,'Ü').replace(/&ouml;/gi,'ö').replace(/&Ouml;/g,'Ö').replace(/&ccedil;/gi,'ç').replace(/&Ccedil;/g,'Ç').replace(/&nbsp;/gi,' '));
function decode(s){return s.replace(/&#(\d+);/g,(_,n)=>String.fromCodePoint(+n)).replace(/&#x([\da-f]+);/gi,(_,n)=>String.fromCodePoint(parseInt(n,16)));}
function cors(origin){return {'Access-Control-Allow-Origin':origin||'*','Access-Control-Allow-Methods':'GET, OPTIONS','Access-Control-Allow-Headers':'Content-Type','Cache-Control':'public, max-age=300'};}
function validDate(s){if(!/^\d{4}-\d{2}-\d{2}$/.test(s||''))return false;const d=new Date(`${s}T12:00:00Z`);return !Number.isNaN(+d)&&d.toISOString().slice(0,10)===s;}
async function fetchText(url){const r=await fetch(url,{headers:{'User-Agent':UA,'Accept':'text/html,application/xhtml+xml'},cf:{cacheTtl:300,cacheEverything:true}});if(!r.ok)throw new Error(`Kaynak HTTP ${r.status}`);return r.text();}
function findEvents(html){const out=[];const re=/<a\b[^>]*href=["']([^"']*\/mac\/[^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi;let m;while((m=re.exec(html))!==null){const href=m[1].startsWith('http')?m[1]:ORIGIN+m[1];const label=textOnly(m[2]).replace(/\s+/g,' ').trim();if(!/\/mac\/\d+\/\d{4}\/\d{2}\/\d{2}\//.test(href)||!label)continue;out.push({url:href,label});}return [...new Map(out.map(x=>[x.url,x])).values()];}
function extractDetail(html,url,label){const t=textOnly(html).replace(/\s+/g,' ').trim();const channels=[];for(const ch of CHANNELS){const re=new RegExp(ch.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'),'i');if(re.test(t))channels.push(ch);}
 const date=(url.match(/\/(\d{4})\/(\d{2})\/(\d{2})\//)||[]).slice(1).join('-');
 const time=(t.match(/(?:Saat\s*)?(\d{1,2}:\d{2})/)||[])[1]||'';
 const title=label.replace(/\s+/g,' ').trim();
 const official=[...html.matchAll(/href=["'](https?:\/\/[^"']+)["'][^>]*>/gi)].map(x=>x[1]).find(x=>/todtv|beinsports|trt|tabii|ssport|aspor|exxen/i.test(x))||'';
 const free=/(şifresiz|sifresiz|ücretsiz|ucretsiz|şifresiz yayın)/i.test(t);
 return {title,date,time,channels:[...new Set(channels)],free,detailUrl:url,watchUrl:official,source:'Yayın Ekranı'};
}
export default {
 async fetch(request,env,ctx){const u=new URL(request.url);const origin=request.headers.get('Origin');if(request.method==='OPTIONS')return new Response(null,{headers:cors(origin)});if(u.pathname!=='/api/broadcasts')return env.ASSETS.fetch(request);
 const date=u.searchParams.get('date');if(!validDate(date))return Response.json({error:'date YYYY-MM-DD biçiminde olmalı'},{status:400,headers:cors(origin)});
 const cacheKey=new Request(`${u.origin}/__cache/broadcasts/${date}`);const cache=caches.default;let cached=await cache.match(cacheKey);if(cached){const body=await cached.json();return Response.json(body,{headers:cors(origin)});}
 try{const day=await fetchText(`${ORIGIN}/gun/${date}`);const events=findEvents(day);const football=events.filter(e=>/(super-lig|trendyol|premier-lig|la-liga|serie-a|bundesliga|ligue-1|champions-lig|avrupa-lig|konferans|turkiye-kup|ulusal-lig|milli|world-cup|dunya-kup|uefa)/i.test(e.url+' '+e.label));
 const rows=await Promise.all(football.slice(0,70).map(async e=>{try{return extractDetail(await fetchText(e.url),e.url,e.label)}catch{return {title:e.label,date,channels:[],detailUrl:e.url,source:'Yayın Ekranı',unavailable:true}}}));
 const result={date,source:'Yayın Ekranı',sourceUrl:`${ORIGIN}/gun/${date}`,updatedAt:new Date().toISOString(),matches:rows};
 const response=new Response(JSON.stringify(result),{headers:{...cors(origin),'Content-Type':'application/json; charset=utf-8','Cache-Control':'public, max-age=300'}});ctx.waitUntil(cache.put(cacheKey,response.clone()));return response;
 }catch(err){return Response.json({date,error:'Yayın programına şu anda ulaşılamadı',detail:String(err),matches:[],source:'Yayın Ekranı',sourceUrl:ORIGIN},{status:502,headers:cors(origin)});}
 }
};
