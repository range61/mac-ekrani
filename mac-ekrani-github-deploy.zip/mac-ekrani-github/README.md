# Maç Ekranı

Tek Cloudflare Worker dağıtımı: statik site + `/api/broadcasts` yayın servisi.

## Cloudflare ile Git bağlantısı

1. Bu klasörün içeriğini bir GitHub deposuna yükleyin.
2. Cloudflare Dashboard → Workers & Pages → Create → Import a repository.
3. GitHub deposunu seçin. Build command: `npx wrangler deploy`; deploy command alanı varsa boş bırakın. Root directory: `/`.
4. Dağıtım tamamlanınca `https://<worker-adresi>.workers.dev` adresi siteyi, `/api/broadcasts?date=YYYY-MM-DD` ise yayın API'sini sunar.

## Yerel dağıtım

`npm install` ardından `npx wrangler deploy`.

## Veri notu

Fikstürler ESPN'in herkese açık skorboard uç noktalarından tarayıcıda alınır. Yayın kanalı servisi Yayın Ekranı sayfalarını sunucu tarafında okur. Kaynağın yeniden kullanım/atıf koşulları ve erişim sürekliliği ayrıca teyit edilmelidir. Kanal eşleşmesi kesin değilse kanal gösterilmemelidir.
